package no.nordicsemi.android.kotlin.ble.app.client.screen.view

data class BlinkyViewState(
    val isButtonPressed: Boolean = false,
    val isLedOn: Boolean = false
)
