package no.nordicsemi.android.kotlin.ble.core.mutex

val SharedMutexWrapper = MutexWrapper()
