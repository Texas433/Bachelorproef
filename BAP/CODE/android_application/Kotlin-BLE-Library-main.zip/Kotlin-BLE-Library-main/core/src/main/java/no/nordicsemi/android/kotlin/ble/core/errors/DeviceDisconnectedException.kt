package no.nordicsemi.android.kotlin.ble.core.errors

class DeviceDisconnectedException : GattException("Operation cannot be performed when device is not connected.")
